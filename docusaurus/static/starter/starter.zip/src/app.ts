import { JsonPipe } from "@angular/common";
import { Component, resource } from "@angular/core";

// Sinequa imports
import { post, Principal, fetchQuery } from "@sinequa/atomic";

@Component({
  selector: 'app-root',
  imports: [JsonPipe],
  template: `
    <h1 class="text-3xl font-bold underline">Hello from {{ principal.value()?.name }}!</h1>
    <details>
      <summary>principal informations</summary>
      <pre>
        {{ principal.value() | json }}
      </pre>
    </details>
    <details>
      <summary>query sample</summary>
      <pre>
        {{ userQuery.value() | json }}
      </pre>
    </details>
  `,
})
export class App {
  name = 'Angular';
  principal = resource({
    loader: async () => {
      const response = await post<Principal>('principal', { action: 'get' });
      if (!response) {
        throw new Error('Failed to fetch users');
      }
      return response;
    },
  });
  userQuery = resource({
    loader: async () => {
      const response = await fetchQuery({
        name: 'training_query',
        text: 'bill gates',
      });
      if (!response) {
        throw new Error('Failed to fetch user settings');
      }
      return response;
    },
  });
}
