import { Component, DestroyRef, inject, signal } from '@angular/core';
import { login, logout } from '@sinequa/atomic';

@Component({
  selector: 'app-root',
  imports: [],
  template: `
    <div class="min-h-screen bg-gray-100 flex items-center justify-center">
      <div class="bg-white p-8 rounded-lg shadow-md w-96 text-center">
        <h1 class="text-2xl font-bold mb-6">Authentication Demo</h1>
        <p class="mb-6 text-gray-600">
          Status:
          {{ isAuthenticated() ? 'Authenticated' : 'Not Authenticated' }}
        </p>

        <div class="space-y-4">
          @if (!isAuthenticated()) {
          <button
            (click)="handleLogin()"
            class="w-full bg-blue-500 text-white px-6 py-3 rounded-md hover:bg-blue-600 transition-colors"
          >
            Login
          </button>
          } @else {
          <button
            (click)="handleLogout()"
            class="w-full bg-red-500 text-white px-6 py-3 rounded-md hover:bg-red-600 transition-colors"
          >
            Logout
          </button>
          }
        </div>
      </div>
    </div>
  `,
})
export class App {
  // Injects
  protected destroyRef = inject(DestroyRef);

  // Signals
  protected isAuthenticated = signal(false);

  constructor() {
    // Automatically log in when the application starts
    this.handleLogin();

    // Set up a destroy handler to log out when the component is destroyed
    // This is useful for cleanup in case the application has a single-page architecture
    this.destroyRef.onDestroy(() => logout());
  }

  protected handleLogin() {
    login().then((value) => this.isAuthenticated.set(value));
  }

  protected handleLogout() {
    this.isAuthenticated.set(false);
    logout();
  }
}
