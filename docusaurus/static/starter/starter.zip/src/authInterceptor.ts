import {
  HttpHandlerFn,
  HttpInterceptorFn,
  HttpRequest,
  HttpResponse,
} from '@angular/common/http';
import {
  getToken,
  globalConfig,
  setToken
} from '@sinequa/atomic';
import { map } from 'rxjs';

// TODO: Replace with your locale name
// const LOCALE_NAME = "fr";

/**
 * Intercepts HTTP requests to add authentication headers and handle CSRF tokens.
 *
 * This interceptor checks if the user is logged in and adds necessary headers
 * to the request, including a CSRF token. If user override is active, it sets
 * the override user and domain headers instead. It also updates the CSRF token
 * from the response headers if present.
 *
 * @param request - The outgoing HTTP request.
 * @param next - The next handler in the HTTP request pipeline.
 * @returns An observable of the HTTP event stream.
 */
export const authInterceptorFn: HttpInterceptorFn = (
  request: HttpRequest<unknown>,
  next: HttpHandlerFn
) => {
  const { userOverride, userOverrideActive, bearerToken } = globalConfig;

  // add auth header with jwt if user is logged in and request is to the api url
  const csrfToken = getToken();

  let headers: Record<string, string> = {
    'Sinequa-Force-Camel-Case': 'true',
    accept: 'application/json',
    'Sinequa-csrf-token': `${csrfToken}`,
    // "x-language": LOCALE_NAME
  };

  if (bearerToken) {
    headers = { ...headers, Authorization: `Bearer ${bearerToken}` };
  }

  if (userOverride && userOverrideActive) {
    headers = {
      ...headers,
      'sinequa-override-user': userOverride.username,
      'sinequa-override-domain': userOverride.domain,
    };
  }

  request = request.clone({
    setHeaders: headers,
  });

  return next(request).pipe(
    map((event) => {
      if (event instanceof HttpResponse) {
        const csrfToken = event.headers.get('sinequa-csrf-token');
        if (csrfToken) {
          setToken(csrfToken);
        }
      }
      return event; // Add this line to fix the return type
    })
  );
};
