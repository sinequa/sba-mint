export const environment = {
  BACKEND_URL: 'https://su-sba.demo.sinequa.com',
  BEARER_TOKEN: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJTaW5lcXVhIiwiaWF0IjoxNzQ4MDA0ODQ1LCJzaWQiOiIwRkJFRUIxOUEyNzU0OUFCQUEzQUU4RkMwNDI1MkVCQyIsImtpbmQiOiJhY2Nlc3MiLCJzdWIiOiJzaW5lcXVhfHVzZXIifQ.KRgkZCTIBy7rM326Ch2c7dDbcegH4R6UAcP-XjEudvw',
  APP_NAME: 'training',
  OAUTH_PROVIDER: 'identity-dev',
};
