import { bootstrapApplication } from '@angular/platform-browser';

// Sinequa imports
import { setGlobalConfig } from '@sinequa/atomic';

import { App } from './app/app';
import { appConfig } from './app/app.config';
import { environment } from './envionments/environment';

setGlobalConfig({
  app: environment.APP_NAME,
  // backendUrl: environment.BACKEND_URL,
  // bearerToken: environment.BEARER_TOKEN,
  autoOAuthProvider: environment.OAUTH_PROVIDER,
});

bootstrapApplication(App, appConfig)
  .catch((err) => console.error(err));
