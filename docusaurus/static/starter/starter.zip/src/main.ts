import {
  provideHttpClient,
  withInterceptors
} from '@angular/common/http';
import {
  inject,
  provideAppInitializer,
  provideZonelessChangeDetection
} from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, Router } from '@angular/router';

import {
  appInitializerFn,
  setGlobalConfig
} from '@sinequa/atomic';
import {
  ApplicationService,
  auditInterceptorFn,
  authInterceptorFn,
  bodyInterceptorFn,
  bootstrapApp,
  errorInterceptorFn,
  toastInterceptorFn,
} from '@sinequa/atomic-angular';
import { App } from './app';
// import { authInterceptorFn } from './authInterceptor'; // to use with stackblitz
import { env } from './env';

setGlobalConfig({
  app: env.APP_NAME,
  // backendUrl: env.BACKEND_URL,
  // bearerToken: env.BEARER_TOKEN,
  // autoOAuthProvider: env.OAUTH_PROVIDER
});


bootstrapApplication(App, {
  providers: [
    provideZonelessChangeDetection(),
    provideRouter([]),
    provideHttpClient(
      withInterceptors([
        bodyInterceptorFn,
        authInterceptorFn,
        auditInterceptorFn,
        errorInterceptorFn,
        toastInterceptorFn,
      ])
    ),
    provideAppInitializer(appInitializerFn),
    provideAppInitializer(() =>
      bootstrapApp(inject(Router), inject(ApplicationService), {
        createRoutes: false,
      })
    ),
  ],
});
